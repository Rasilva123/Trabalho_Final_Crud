﻿using Cadastro_Aluno.dao;
using Cadastro_Aluno.Modelos;

class Program
{
    static void Main(string[] args)
    {
        ModeloDao mode1 = new ModeloDao();
        mode1.Menu();
    }
}