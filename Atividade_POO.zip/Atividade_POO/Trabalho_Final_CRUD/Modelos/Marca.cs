﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cadastro_Modelo.Modelos
{
    internal class Marca
    {
        public int id_marca { get; set; }

        public string nome { get; set; }
    }
}
